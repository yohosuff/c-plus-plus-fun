Microsoft Visual Studio Express 2012 for Windows Desktop
File>New Project
Search Installed Templates

Debugging Configuration Properties

Command:

$(OGRE_HOME)\Bin\$(Configuration)\$(ProjectName).exe

Working Directory:

$(OGRE_HOME)\Bin\$(Configuration)